/**
 * @Author:Otosun Tarih :21/09/2020
 */
package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;
import java.util.Random;

public class Tools {

    public static void compareList(List<WebElement> webElmList, List<String> stringList) {
        int i = 0;
        for (WebElement e : webElmList) {
            Assert.assertEquals(e.getText(), stringList.get(i++));
            // System.out.println(e.getText());
        }
    }
    public static void succesMessageValidation(WebDriver driver){
        WebElement checkText = driver.findElement(By.xpath("//div[@class='alert alert-success']"));
        //   System.out.println(checkText.getText());
        Assert.assertTrue(checkText.getText().contains("successfully"));
    }
    public static int randomNum(int max) {
        Random rnd=new Random();
        int randomNumber= rnd.nextInt(max-1)+1;

        return randomNumber;
    }
    public static void selectByIndex(WebElement dropDownName){
        Select _select=new Select(dropDownName);
        _select.selectByIndex(randomNum(_select.getOptions().size()));
    }

    public static void ListContainsString(List<WebElement> webElmList, String expectedString) {
        boolean bulundu=false;
        for (WebElement e : webElmList) {
            if (e.getText().contains(expectedString)){
                bulundu=true;
                break;
            }
        }
        Assert.assertTrue(bulundu,"aranan eleman bulunamadi");
    }
}
