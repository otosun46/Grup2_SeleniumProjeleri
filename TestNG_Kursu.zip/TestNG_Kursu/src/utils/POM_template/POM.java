/**
 * @Author:Otosun Tarih :29/09/2020
 */
package utils.POM_template;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

public class POM extends MetodWebDriver {
    @Test
    public void ProcedToCheckout() {
        POM_Elements pomElements=new POM_Elements(driver);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        pomElements.abc.sendKeys("ipod");
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.def)).click();

    }
}
