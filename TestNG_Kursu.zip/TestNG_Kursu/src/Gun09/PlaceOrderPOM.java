/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun09;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

public class PlaceOrderPOM extends MetodWebDriver {
    @Test
    public void ProcedToCheckout(){
        PlaceOrderElement placeOrderElement=new PlaceOrderElement(driver);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        placeOrderElement.serch.sendKeys("ipod");
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.serchbutton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.adToCart)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.ShoppingCart)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.checkoutButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.continiu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.continueShipping)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.continueShippingMethod)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.checkBox)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.Continucash)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.confirmButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderElement.continueOnay)).click();
    }
}
