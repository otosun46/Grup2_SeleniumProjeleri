/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun09;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

/*
Seneryo
1- Siteyi aciniz
2- Sitede "Palm" kelimesini aratiniz
3- Cikan sonuclardan ilkini sepete atiniz
4- Sepete(ShoppingCart) tiklatiniz
5- Checkout yapiniz

 */
public class PlaceOrder extends MetodWebDriver {
    @Test
    public void siparisMetodu() throws InterruptedException {
        WebElement serch=driver.findElement(By.cssSelector(".form-control.input-lg"));
        serch.sendKeys("ipod");
        WebElement serchbutton=driver.findElement(By.cssSelector(".input-group-btn"));
        serchbutton.click();
        WebDriverWait wait = new WebDriverWait(driver, 5);


        WebElement adToCart=driver.findElement(By.xpath("(//div[@class='button-group']/button)[1]"));
        wait.until(ExpectedConditions.visibilityOf(adToCart));
        adToCart.click();

        WebElement ShoppingCart=driver.findElement(By.xpath("(//i[@class='fa fa-shopping-cart'])[1]"));
        ShoppingCart.click();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1200)");
        WebElement checkoutButton=driver.findElement(By.xpath("//div[@class='pull-right']"));
        //wait.until(ExpectedConditions.visibilityOf(adToCart));
        checkoutButton.click();

        WebElement continiu=driver.findElement(By.cssSelector("#button-payment-address"));
        continiu.click();

        WebElement continueShipping=driver.findElement(By.cssSelector("#button-shipping-address"));//button-shipping-address
        continueShipping.click();
        WebElement continueShippingMethod=driver.findElement(By.cssSelector("#button-shipping-method"));//button-shipping-address
        continueShippingMethod.click();
        js.executeScript("window.scrollBy(0,400)");

        WebElement checkBox=driver.findElement(By.cssSelector("input[type=checkbox]"));
        checkBox.click();


        WebElement Continucash=driver.findElement(By.id("button-payment-method"));
        Continucash.click();

        WebElement confirmButton=driver.findElement(By.id("button-confirm"));
        confirmButton.click();
        Thread.sleep(1000);
        WebElement continueOnay=driver.findElement(By.xpath("//div[@class='pull-right']"));
        continueOnay.click();

    }
}
