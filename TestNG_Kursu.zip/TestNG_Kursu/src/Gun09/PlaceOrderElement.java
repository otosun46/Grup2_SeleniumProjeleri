/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun09;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PlaceOrderElement {
    public PlaceOrderElement(WebDriver driver) {
        PageFactory.initElements(driver,this);
    }

    @FindBy(css=".form-control.input-lg")
    public WebElement serch;

    @FindBy(css=".input-group-btn")
    public WebElement serchbutton;

    @FindBy(xpath="(//div[@class='button-group']/button)[1]")
    public WebElement adToCart;

    @FindBy(xpath="(//i[@class='fa fa-shopping-cart'])[1]")
    public WebElement ShoppingCart;

    @FindBy(xpath="//div[@class='pull-right']")
    public WebElement checkoutButton;

    @FindBy(css="#button-payment-address")
    public WebElement continiu;

    @FindBy(css="#button-shipping-address")
    public WebElement continueShipping;

    @FindBy(css="#button-shipping-method")
    public WebElement continueShippingMethod;

    @FindBy(css="input[type=checkbox]")
    public WebElement checkBox;

    @FindBy(id="button-payment-method")
    public WebElement Continucash;

    @FindBy(id="button-confirm")
    public WebElement confirmButton;

    @FindBy(xpath="//div[@class='pull-right']")
    public WebElement continueOnay;



}
