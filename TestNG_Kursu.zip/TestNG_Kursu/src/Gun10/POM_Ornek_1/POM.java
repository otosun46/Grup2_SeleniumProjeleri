/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun10.POM_Ornek_1;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.MetodWebDriver_nonLogin;

public class POM extends MetodWebDriver_nonLogin {
    @Test
    public void ProcedToCheckout() {
        driver.get("http://demowebshop.tricentis.com/");
        POM_Elements pomElements=new POM_Elements(driver);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.login)).click();
        pomElements.mail.clear();
        pomElements.mail.sendKeys("asds123@gmail.com");
        pomElements.password.clear();
        pomElements.password.sendKeys("HasSah123");
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.loginButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.computer)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.desktops)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.adToCart)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.prossesor)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.ram8Gb)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.hdd400Gb)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.otherOfficeSuit)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.addToCartButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.topcartlink)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.Iagree)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.checkoutButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.continiu)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.continueShipping)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.continueShippingMethod)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.cash)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.continuePaymentMethod)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.continuePaymentInform)).click();
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.confirmOrder)).click();
        String succes= wait.until(ExpectedConditions.elementToBeClickable(pomElements.orderSucces)).getText();
        System.out.println(succes);
        Assert.assertTrue(succes.contains("successfully"));
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.son)).click();


    }
}
