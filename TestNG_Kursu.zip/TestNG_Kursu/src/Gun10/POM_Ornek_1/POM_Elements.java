/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun10.POM_Ornek_1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class POM_Elements {
    public POM_Elements(WebDriver driver) {
        PageFactory.initElements(driver,this);
    }
    @FindBy(css=".ico-login")
        public WebElement login;

    @FindBy(id ="Email")
    public WebElement mail;

    @FindBy(id ="Password")
    public WebElement password;

    @FindBy(className = "login-button")
    public WebElement loginButton;

    @FindBy(xpath="(//a[@href='/computers'])[3]")
    public WebElement computer;

    @FindBy(xpath="(//a[@href='/desktops'])[3]")
    public WebElement desktops;

    @FindBy(xpath="(//div[@class='add-info']/div[2])[3]")
    public WebElement adToCart;

    @FindBy(id ="product_attribute_74_5_26_82")
    public WebElement prossesor;

    @FindBy(id ="product_attribute_74_6_27_85")
    public WebElement ram8Gb;

    @FindBy(id ="product_attribute_74_3_28_87")
    public WebElement hdd400Gb;

    @FindBy(id ="product_attribute_74_8_29_90")
    public WebElement otherOfficeSuit;

    @FindBy(id ="add-to-cart-button-74")
    public WebElement addToCartButton;

    @FindBy(id ="topcartlink")
    public WebElement topcartlink;

    @FindBy(id ="termsofservice")
    public WebElement Iagree;

    @FindBy(id ="checkout")
    public WebElement checkoutButton;

    @FindBy(css="#billing-buttons-container>.button-1")
    public WebElement continiu;

    @FindBy(css="#shipping-buttons-container>.button-1")
    public WebElement continueShipping;

    @FindBy(css=".shipping-method-next-step-button")
    public WebElement continueShippingMethod;

    @FindBy(id ="paymentmethod_0")
    public WebElement cash;

    @FindBy(css=".payment-method-next-step-button")
    public WebElement continuePaymentMethod;

    @FindBy(css=".payment-info-next-step-button")
    public WebElement continuePaymentInform;

    @FindBy(css=".confirm-order-next-step-button")
    public WebElement confirmOrder;

    @FindBy(css=".order-completed>div>strong")
    public WebElement orderSucces;

    @FindBy(css=".order-completed-continue-button")
    public WebElement son;





}
