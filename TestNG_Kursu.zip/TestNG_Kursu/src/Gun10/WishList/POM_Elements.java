/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun10.WishList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class POM_Elements {
    public POM_Elements(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "input[name='search']")
    public WebElement searchInput;
    @FindBy(xpath = "//button[@class='btn btn-default btn-lg']")
    public WebElement searchButton;


    @FindAll({
            @FindBy(css = "div[class='caption']>h4")
    })
    public List<WebElement> pruductList;

    @FindAll({
            @FindBy(css = "button[data-original-title='Add to Wish List']")
    })
    public List<WebElement> searchResultWishList;

    @FindAll({
            @FindBy(xpath = "//table[@class='table table-bordered table-hover']//tbody//td[2]")
    })
    public List<WebElement> tableNames;

    @FindBy(id="wishlist-total")
    public WebElement wishListLink;

}
