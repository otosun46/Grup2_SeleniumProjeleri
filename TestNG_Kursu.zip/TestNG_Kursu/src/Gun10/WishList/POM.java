/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun10.WishList;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.ParameterDriver;
import utils.Tools;

import java.util.List;

public class POM extends ParameterDriver {
    @Test
    @Parameters("itemName")
    public void addToWishList(String itemName) {
        POM_Elements pomElements=new POM_Elements(driver);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        pomElements.searchInput.sendKeys(itemName);
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.searchButton)).click();
        int RundNumber= Tools.randomNum(pomElements.pruductList.size());
        String wishItemName=pomElements.pruductList.get(RundNumber).getText();
        pomElements.searchResultWishList.get(RundNumber).click();
        pomElements.wishListLink.click();
        Tools.ListContainsString(pomElements.tableNames,wishItemName);



    }
    @Test
    public void Test1(){
        System.out.println("merhaba");
        Assert.fail();
    }
}
