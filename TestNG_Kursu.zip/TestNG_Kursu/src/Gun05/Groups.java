/**
 * @Author:Otosun Tarih :23/09/2020
 */
package Gun05;

import org.testng.annotations.Test;

public class Groups {
    @Test(groups = "Regression")
    public void Test1(){System.out.println("Regression Test1");}
    @Test(groups = "Regression")
    public void Test2(){System.out.println("Regression Test2");}
    @Test(groups = "Regression")
    public void Test5(){System.out.println("Regression Test5");}
    @Test(groups = "Regression")
    public void Test7(){System.out.println("Regression Test7");}
    @Test(groups = "SmokeTest")
    public void Test3(){System.out.println("Smoke Test3");}
    @Test
    public void Test6(){System.out.println("Test6");}
    @Test(groups = "SmokeTest")
    public void Test4(){System.out.println("Smoke Test4");}

}
