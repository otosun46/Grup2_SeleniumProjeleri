/**
 * @Author:Otosun Tarih :23/09/2020
 */
package Gun05;

import org.testng.annotations.Test;

public class Intro_2 {
    @Test
    public void Test1(){System.out.println("Intro_2-> Test1");}
    @Test
    public void Test2(){System.out.println("Intro_2-> Test2");}
}
