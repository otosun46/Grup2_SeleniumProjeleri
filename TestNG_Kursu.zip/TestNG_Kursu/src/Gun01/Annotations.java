/**
 * @Author:Otosun Tarih :17/09/2020
 */
package Gun01;

import org.testng.annotations.*;

/*
      @BeforeClass      -> Her Classdan önce çalışacaklar buraya yazılıyor.
         @BeforeMethod  -> Her metod çalışmadan önce yapılacakları buraya yazıyoruz
                  @Test  -> testimiz
                  @Test
         @AfterMethod   -> Her metod çalıştıktan sonra yapılacakları buraya yazıyoruz.
      @AfterClass       -> Her class dan sonra yapıalcaklar buraya yazılıyor.
 */
public class Annotations {
    @BeforeClass
    void beforeClass(){
        System.out.println("Clastan once calisacak");
    }
    @AfterClass
    void afterClass(){
        System.out.println("Class sonra calisacak");
    }
    @BeforeMethod
    void beforeMetod(){
        System.out.println("Metodtan once calisacak");
    }
    @AfterMethod
    void afterMetod(){
        System.out.println("Metodtan sonra calisacak");
    }
    @Test
    void test1(){
        System.out.println("Burasi test_1");
    }
    @Test
    void test2(){
        System.out.println("Burasi test_2");
    }
}
