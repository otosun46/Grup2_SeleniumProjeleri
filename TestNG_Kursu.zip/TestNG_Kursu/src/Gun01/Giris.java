/**
 * @Author:Otosun Tarih :17/09/2020
 */
package Gun01;


import org.testng.annotations.Test;

public class Giris {
    @Test
    void  webSitesiAc(){
        System.out.println("Driver tanimlandi, ve web sitesi acildi...");
    }
    @Test
    void loginTest(){
        System.out.println("Login test");

    }
    @Test
    void driverKapat(){
        System.out.println("Driver tanimlandi");
    }
}
