/**
 * @Author:Otosun Tarih :17/09/2020
 */
package Gun01;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertions {
    @Test
    void EqualOrnek(){
        String s1="Ahmet";
        String s2="Mehmet";
        Assert.assertEquals(s1,s2);
    }

    @Test
    void TrueOrnek(){
        int s1=5;
        int s2=7;
        Assert.assertTrue(s1==s2);
    }
    @Test
    void NullOrnek(){
       // String s=null;
        String[] dizi=new String[3];
        Assert.assertNull(dizi[2]);
    }
}
