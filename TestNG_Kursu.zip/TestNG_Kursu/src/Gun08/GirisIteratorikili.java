/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class GirisIteratorikili {
    @Test(dataProvider = "getData2")
    public void LoginTest(String usename,String password){
        System.out.println(usename+" "+password);
    }

    @DataProvider
    public Iterator<Object[]> getData2(){

        List<Object[]> data= new ArrayList<>();

        data.add(new Object[]{"Ahmet","xyz"});
        data.add(new Object[]{"ayse","abc"});
        data.add(new Object[]{"mehmet","klm"});

        return data.iterator();
    }
}
