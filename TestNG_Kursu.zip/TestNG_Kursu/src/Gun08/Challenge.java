/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun08;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class Challenge {
    public static WebDriver driver;

    @BeforeClass
    public void beforeClass() {
        System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");
        System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        driver.get("http://www.autotrader.com/");
    }

    @Test
    public void QAAutomationCodeChallenge() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, 5);
        Thread.sleep(3000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='container text-center text-sm-left']")));//bu sayfanin altinda bir locater bunu denemek icin ekledim
                                                                                                                                //bazen calisti bazen calismadi
        driver.manage().deleteAllCookies();
        WebElement browseByMake = driver.findElement(By.xpath("(//button[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0 btn btn-link'])[1]"));
        WebElement browseByStyle = driver.findElement(By.xpath("(//button[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0 btn btn-link'])[2]"));
        WebElement advanceSearche = driver.findElement(By.xpath("//a[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0']"));
        WebElement searche = driver.findElement(By.id("search"));
        WebElement makeLst = driver.findElement(By.id("makeCode"));
        WebElement modelLst = driver.findElement(By.id("ModelCode"));
        driver.manage().deleteAllCookies();
        advanceSearche.click();
        WebElement zipCode = driver.findElement(By.id("zip"));
        zipCode.sendKeys("30004");
        WebElement certified = driver.findElement(By.xpath("(//div[@class='col col-xs-4 col-lg-2'])[3]"));
        wait.until(ExpectedConditions.visibilityOf(certified));
        certified.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
        js.executeScript("window.scrollBy(0,400)");
        WebElement convertibleAlan = driver.findElement(By.xpath("//label[@class='checkbox btn btn-default checkbox-btn']/div"));

        convertibleAlan.click();
        driver.manage().deleteAllCookies();

        WebElement modelilk = driver.findElement(By.id("4101482096"));
        wait.until(ExpectedConditions.visibilityOf(modelilk));
        Select modelYililk = new Select(modelilk);
        modelYililk.selectByValue("2017");
        WebElement modelSon = driver.findElement(By.id("258002540"));
        wait.until(ExpectedConditions.visibilityOf(modelSon));
        Select modelYilSon = new Select(modelSon);
        modelYilSon.selectByValue("2020");
        WebElement make = driver.findElement(By.id("1970425032"));
        Select modelMake = new Select(make);
        modelMake.selectByValue("BMW");
        WebElement searchButton = driver.findElement(By.xpath("//div[@class='text-center justify-content-center justify-content-sm-start margin-horizontal-sm-0 margin-horizontal-5']"));
        searchButton.click();
        Thread.sleep(3000);
        driver.quit();
    }

}
