/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class GirisIkili {
        @Test(dataProvider = "getData")
        public void LoginTest(String usename,String password){
            System.out.println(usename+" "+password);
        }

        @DataProvider
        public Object[][] getData(){
           Object[][] data= {
                   {"Ahmet","abc"},
                   {"ayse","zyx"},
                   {"mehmet","tde"}
           };
            return data;
        }

    }
