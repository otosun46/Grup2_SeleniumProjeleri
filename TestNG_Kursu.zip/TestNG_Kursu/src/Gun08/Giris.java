/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
/**
 * Aşağıdaki ikli ile Dataproviderın içindeki bütün veriler tek tek test e gönderilerek
 * data sayısı kadar test çalıştırılı, dataların olduğu yere DataProvider annottion ı konur.
 * çalıştırılacak teste ise dataProvider = "getData"  bölümü eklenir.
 */
public class Giris {
    @Test(dataProvider = "getData")
    public void UserNameTest(String usename){
        System.out.println(usename);
    }
    //Data provider must return Object[][]/Object[] or Iterator<Object[]>/Iterator<Object>
    @DataProvider
    public Object[] getData(){
        Object[] data={
                "ahmet",
                "ayse",
                "mehmet",
                "fatma"
        };
     return data;
    }

    @Test(dataProvider = "UsersDataProvider")
    public void UserNameTest2(String usename){
        System.out.println(usename);
    }

    @DataProvider(name = "UsersDataProvider") //DataProvidere isim verdik
    public Object[] getData2(){
        Object[] data={
                "ahmet",
                "ayse",
                "mehmet",
                "fatma"
        };
        return data;
    }
}
