/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

import java.util.List;

/**
 * Daha onceki derslerde yaptigimiz search foncsiyonunu
 * Mac ve Laptop icin Dataprovider ile yapiniz.
 *
 */

public class Task_1 extends MetodWebDriver {
        @Test(dataProvider = "urunDataProvider")
        //@Parameters("arananKelime")
        public void Test1(String arananKelime) throws InterruptedException {//String arananKelime
            WebElement searchBar=driver.findElement(By.cssSelector("#search>input[type=\"text\"]"));
            searchBar.clear();
            searchBar.sendKeys(arananKelime);
            //Thread.sleep(1000);
            WebElement searchButton=driver.findElement(By.cssSelector(".input-group-btn"));
            searchButton.click();
            List<WebElement> urunListesi=driver.findElements(By.cssSelector(".product-thumb>div>div>h4>a")); //.product-thumb>div>div>p:not(.price)"));
            for (WebElement e:urunListesi) {
                System.out.println(e.getText());
                System.out.println();
                Assert.assertTrue(e.getText().toLowerCase().contains(arananKelime));

            }
        }

        @DataProvider(name = "urunDataProvider") //DataProvidere isim verdik
        public Object[] getData2(){
            Object[] data={
                    "mac",
                    "samsung"
            };
            return data;
        }

    }
