/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.ParameterDriver;

import java.util.List;

/*
1- _04_Task1   deki testi ParameterDriver ile yapınız.
2- _04_Task1   deki testi daha önce yapılan ContacUs için yapınız.Birden fazla mesaj için.
 */
public class Odev extends ParameterDriver {
    @Test(dataProvider = "urunDataProvider")
    //@Parameters("arananKelime")
    public void Test1(String arananKelime) {//String arananKelime
        WebElement searchBar=driver.findElement(By.cssSelector("#search>input[type=\"text\"]"));
        searchBar.clear();
        searchBar.sendKeys(arananKelime);
        WebElement searchButton=driver.findElement(By.cssSelector(".input-group-btn"));
        searchButton.click();
        List<WebElement> urunListesi=driver.findElements(By.cssSelector(".product-thumb>div>div>h4>a")); //.product-thumb>div>div>p:not(.price)"));
        for (WebElement e:urunListesi) {
            System.out.println(e.getText());
            System.out.println();
            Assert.assertTrue(e.getText().toLowerCase().contains(arananKelime.toLowerCase()));

        }
    }

    @DataProvider(name = "urunDataProvider") //DataProvidere isim verdik
    public Object[] getData(){
        Object[] data={
                "Mac",
                "Samsung"
        };
        return data;
    }
}
