/**
 * @Author:Otosun Tarih :28/09/2020
 */
package Gun08;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class GirisIterator {
    @Test(dataProvider = "getData")
    public void LoginTest(String usename){
        System.out.println(usename);
    }

    @DataProvider
    public Iterator<Object> getData(){
        List<Object> data= new ArrayList<>();
        data.add("Ahmet");
        data.add("ayse");
        data.add("mehmet");

        return data.iterator();
    }
}
