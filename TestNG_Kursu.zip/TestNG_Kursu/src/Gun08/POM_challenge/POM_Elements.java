/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun08.POM_challenge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class POM_Elements {
    public POM_Elements(WebDriver driver) {
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="(//button[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0 btn btn-link'])[1]")
    public WebElement browseByMake;

    @FindBy(xpath="(//button[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0 btn btn-link'])[2]")
    public WebElement browseByStyle;

    @FindBy(xpath="//a[@class='text-size-5 text-size-sm-10 text-link text-bold padding-0']")
    public WebElement advanceSearche;

    @FindBy(id ="search")
    public WebElement searche;

    @FindBy(id ="makeCode")
    public WebElement makeLst;

    @FindBy(id ="ModelCode")
    public WebElement modelLst;

    @FindBy(id ="zip")
    public WebElement zipCode;

    @FindBy(xpath = "(//div[@class='col col-xs-4 col-lg-2'])[3]")
    public WebElement certified;

    @FindBy(xpath = "//label[@class='checkbox btn btn-default checkbox-btn']/div")
    public WebElement convertibleAlan;

    @FindBy(id ="4101482096")
    public WebElement modelilk;

    @FindBy(id ="258002540")
    public WebElement modelSon;

    @FindBy(id ="1970425032")
    public WebElement make;

    @FindBy(xpath = "//div[@class='text-center justify-content-center justify-content-sm-start margin-horizontal-sm-0 margin-horizontal-5']")
    public WebElement searchButton;

}
