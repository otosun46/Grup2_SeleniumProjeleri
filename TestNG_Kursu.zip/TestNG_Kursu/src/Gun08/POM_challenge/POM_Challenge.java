/**
 * @Author:Otosun Tarih :29/09/2020
 */
package Gun08.POM_challenge;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;


public class POM_Challenge extends MethodWebDriver_nonLogin {

    @Test
    public void ProcedToCheckout() throws InterruptedException {
        driver.get("http://www.autotrader.com/");
        Thread.sleep(4000);
        driver.manage().deleteAllCookies();
        POM_Elements pomElements=new POM_Elements(driver);
        WebDriverWait wait = new WebDriverWait(driver, 5);

        List<WebElement> ogeler=new ArrayList<>();
        ogeler.add(pomElements.browseByMake);
        ogeler.add(pomElements.browseByStyle);
        ogeler.add(pomElements.advanceSearche);
        ogeler.add(pomElements.searche);
        ogeler.add(pomElements.make);
        ogeler.add(pomElements.modelLst);

        wait.until(ExpectedConditions.elementToBeClickable(pomElements.advanceSearche)).click();
        pomElements.zipCode.sendKeys("30004");
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.certified)).click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,400)");
        wait.until(ExpectedConditions.elementToBeClickable(pomElements.convertibleAlan)).click();
        Select modelYililk = new Select(pomElements.modelilk);
        modelYililk.selectByValue("2010");
        Select modelYilSon=new Select(pomElements.modelSon);
        modelYilSon.selectByValue("2020");
        js.executeScript("window.scrollBy(0,400)");
        Select modelMake= new Select(pomElements.make);
        modelMake.selectByValue("BMW");
        Thread.sleep(3000);

        js.executeScript("window.scrollBy(0,1000)");
        pomElements.searchButton.click();
        for (WebElement oge:ogeler) {
            Assert.assertTrue(oge.isDisplayed());
        }
        driver.manage().deleteAllCookies();
    }
}
