/**
 * @Author:Otosun Tarih :22/09/2020
 */
package Gun04;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.Tools;

import java.util.List;

public class AdressFunctionality extends MetodWebDriver {
    @Test
    void AddAddress() throws InterruptedException {
        WebElement adressBook = driver.findElement(By.xpath("(//a[@class='list-group-item'])[4]"));
        adressBook.click();
        WebElement adAddressButton = driver.findElement(By.cssSelector("a[class='btn btn-primary']"));
        adAddressButton.click();


        WebElement firstName = driver.findElement(By.id("input-firstname"));
        firstName.sendKeys("Hasan");
        WebElement lastName = driver.findElement(By.id("input-lastname"));
        lastName.sendKeys("Sahan");
        WebElement company = driver.findElement(By.id("input-company"));
        company.sendKeys("Techno Soft");
        WebElement address1 = driver.findElement(By.id("input-address-1"));
        address1.sendKeys("Spenshult 101");
        WebElement address2 = driver.findElement(By.id("input-address-2"));
        address2.sendKeys("Oskarstrom");
        WebElement city = driver.findElement(By.id("input-city"));
        city.sendKeys("Oskarstrom");
        WebElement postcode = driver.findElement(By.id("input-postcode"));
        postcode.sendKeys("91 303");
        WebElement coutryElm = driver.findElement(By.id("input-country"));
        Tools.selectByIndex(coutryElm);
        By stateOption = By.xpath("//select[@id='input-zone']/option");
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(stateOption, 1));
        Thread.sleep(1000);
        WebElement zoneElm = driver.findElement(By.id("input-zone"));
        Tools.selectByIndex(zoneElm);
        WebElement defaultAddress = driver.findElement(By.xpath("(//label[@class='radio-inline'])[2]"));
        defaultAddress.click();
        WebElement continueButton = driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        continueButton.click();
        Tools.succesMessageValidation(driver);
    }

    @Test//(dependsOnMethods = {"AddAddress"})
    void EditAddress() {
        WebElement adressBook = driver.findElement(By.xpath("(//a[@class='list-group-item'])[4]"));
        adressBook.click();
        List<WebElement> adresses = driver.findElements(By.xpath("//a[@class='btn btn-info']"));
        adresses.get(adresses.size()-1).click();
        WebElement firstName = driver.findElement(By.id("input-firstname"));
        firstName.clear();
        firstName.sendKeys("Huseyin");
        WebElement lastName = driver.findElement(By.id("input-lastname"));
        lastName.clear();
        lastName.sendKeys("Sahanli");
        WebElement continueButton = driver.findElement(By.xpath("//input[@class='btn btn-primary']"));

        continueButton.click();
        Tools.succesMessageValidation(driver);
    }
    @Test//(dependsOnMethods = {"EditAddress"})
    void DeleteAddress() throws InterruptedException {
        WebElement adressBook = driver.findElement(By.xpath("(//a[@class='list-group-item'])[4]"));
        adressBook.click();

        List<WebElement> adresses = driver.findElements(By.xpath("//a[@class='btn btn-danger']"));
//        for (int i=1;i<adresses.size()-2;i++) {
//            adresses.get(i).click();
//            Thread.sleep(1000);
//        }
        adresses.get(adresses.size()-1).click();
        Tools.succesMessageValidation(driver);
    }
}
