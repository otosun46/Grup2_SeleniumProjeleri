/**
 * @Author:Otosun Tarih :22/09/2020
 */
package Gun04;

import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

public class Dependency {
    @Test
    void startCar(){
        System.out.println("Car started");

    }
    @Test(dependsOnMethods = {"startCar"})
    void driveCar(){
        System.out.println("Car drived");
    }
    @Test(dependsOnMethods = {"driveCar"})
    void stopCar(){
        System.out.println("Car stoped");
     //   Assert.fail();
    }
    @Test(dependsOnMethods = {"stopCar","driveCar"},alwaysRun = true)
    void parkCar(){
        System.out.println("Car parked");
    }
}
