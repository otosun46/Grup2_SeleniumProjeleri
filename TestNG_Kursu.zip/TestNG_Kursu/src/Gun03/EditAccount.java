/**
 * @Author:Otosun Tarih :21/09/2020
 */
package Gun03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.Tools;

public class EditAccount extends MetodWebDriver {
    @Test
            void editAccount() throws InterruptedException {
        WebElement editAccount=driver.findElement(By.xpath("(//a[@class='list-group-item'])[2]"));
        editAccount.click();
        WebElement firstName=driver.findElement(By.id("input-firstname"));
        String oldName=firstName.getAttribute("value");
        System.out.println(oldName);
        WebElement lastName=driver.findElement(By.id("input-lastname"));
        String oldLastName=lastName.getAttribute("value");
        System.out.println(oldLastName);
        firstName.clear();
        firstName.sendKeys("Ismet");
        lastName.clear();
        lastName.sendKeys("Yilmaz");
        Thread.sleep(1000);
        firstName.clear();
        firstName.sendKeys(oldName);
        lastName.clear();
        lastName.sendKeys(oldLastName);
        WebElement submitButton=driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        submitButton.click();
        Tools.succesMessageValidation(driver);
    }

}
