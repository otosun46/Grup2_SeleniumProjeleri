/**
 * @Author:Otosun Tarih :17/09/2020
 */
package Gun03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.Tools;

import java.util.ArrayList;
import java.util.List;

/*
     1- http://opencart.abstracta.us/index.php?route=account/login  sitesini açınız.
     2- asd@gmail.com  ve 123qweasd   bilgileri ile login olan test metodunu yazınız.
     3- Login olup olmadığınızı assert ile kontrol ediniz.
     4- bir utils paketi açınız ve buraya beforeClass ve afterClass metdolarını yazarak
        genel kullanım için MetodWebDriver isimli test klasını tanımlayınız.
 */
public class Validation extends MetodWebDriver {

    @Test
    void menuValidation(){
        List<String>menuList=new ArrayList<>();
        menuList.add("Desktops");
        menuList.add("Laptops & Notebooks");
        menuList.add("Components");
        menuList.add("Tablets");
        menuList.add("Software");
        menuList.add("Phones & PDAs");
        menuList.add("Cameras");
        menuList.add("MP3 Players");
        By menu=By.xpath("//ul[@class='nav navbar-nav']/li");
        List<WebElement>MenuActionList=driver.findElements(menu);
        Tools.compareList(MenuActionList,menuList);
    }
}
