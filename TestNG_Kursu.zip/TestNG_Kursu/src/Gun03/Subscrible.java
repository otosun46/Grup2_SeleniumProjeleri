/**
 * @Author:Otosun Tarih :21/09/2020
 */
package Gun03;
/*
Siteyi aciniz
Newslatter Sbscribe ve unsubscribe
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.Tools;

public class Subscrible extends MetodWebDriver {

    @Test
    void subscribeFunctionYes() throws InterruptedException {
        WebElement yazi = driver.findElement(By.xpath("//a[text()='Subscribe / unsubscribe to newsletter']"));
        yazi.click();

        WebElement yes = driver.findElement(By.xpath("(//label[@class='radio-inline'])[1]"));
        yes.click();

        WebElement submitButton = driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        submitButton.click();

        Tools.succesMessageValidation(driver);
    }

    @Test
    void subscribeFunctionNo() throws InterruptedException {
        WebElement yazi = driver.findElement(By.xpath("//a[text()='Subscribe / unsubscribe to newsletter']"));
        yazi.click();

        WebElement no = driver.findElement(By.xpath("(//label[@class='radio-inline'])[2]"));
        no.click();

        WebElement submitButton = driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        submitButton.click();

        Tools.succesMessageValidation(driver);
    }

    @Test
    void subscribeFunctionBoth() throws InterruptedException {
        WebElement yazi = driver.findElement(By.xpath("//a[text()='Subscribe / unsubscribe to newsletter']"));
        yazi.click();

        WebElement yes = driver.findElement(By.xpath("(//label[@class='radio-inline'])[1]"));
        WebElement no = driver.findElement(By.xpath("(//label[@class='radio-inline'])[2]"));
        Thread.sleep(1000);
        if (yes.isSelected()) {
            no.click();
        } else yes.click();
        Thread.sleep(1000);

        WebElement submitButton = driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        submitButton.click();

        Tools.succesMessageValidation(driver);
    }
}
