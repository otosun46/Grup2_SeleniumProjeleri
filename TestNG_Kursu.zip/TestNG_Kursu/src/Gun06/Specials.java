/**
 * @Author:Otosun Tarih :24/09/2020
 */
package Gun06;
/*
        Senaryo-2
        1- Siteye gidiniz
        2- Specials tiklayiniz
        3- Cikan urun sayisi ile indirimli urun sayisi ayni mi dogrulayiniz

     */

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

import java.util.List;

public class Specials extends MetodWebDriver {
    @Test
    void TestSpesials(){
    WebElement spesialsText=driver.findElement(By.linkText("Specials"));
    spesialsText.click();
        List<WebElement> urunler=driver.findElements(By.cssSelector(".product-thumb"));
        List<WebElement> indirimliUrunler=driver.findElements(By.cssSelector("span.price-old"));
        Assert.assertTrue(urunler.size()==indirimliUrunler.size());
    }
}
