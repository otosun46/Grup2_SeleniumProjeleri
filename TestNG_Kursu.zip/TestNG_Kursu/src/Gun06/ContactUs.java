/**
 * @Author:Otosun Tarih :24/09/2020
 */
package Gun06;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utils.MetodWebDriver;

public class ContactUs extends MetodWebDriver {
    @Test
    @Parameters("enquiry")
    public void contactUs(String enquiry){
        WebElement contact=driver.findElement(By.linkText("Contact Us"));
        contact.click();
        WebElement enquiryInput=driver.findElement(By.id("input-enquiry"));
        enquiryInput.sendKeys(enquiry);
        WebElement submitButton=driver.findElement(By.xpath("//input[@class='btn btn-primary']"));
        submitButton.click();
        WebElement succesText=driver.findElement(By.cssSelector("#content>p"));
        Assert.assertTrue(succesText.getText().toLowerCase().contains("successfully"));
        WebElement continuButton=driver.findElement(By.xpath("//a[@class='btn btn-primary']"));
        continuButton.click();
    }
}
