/**
 * @Author:Otosun Tarih :24/09/2020
 */
package Gun06;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utils.MetodWebDriver;
import utils.ParameterDriver;

import java.util.List;

/*
      Senaryo ;
      1- Siteyi açınız.
      2- mac kelimesini göndererek aratınız.
      3- Çıkan sonuçlarda mac kelimesinin geçtiğini doğrulayınız.
    */
public class SearchFunctionalityParameterBrowser extends ParameterDriver {
    @Test
    @Parameters("arananKelime")
    public void Test1(String arananKelime){//String arananKelime
        WebElement searchBar=driver.findElement(By.cssSelector("#search>input[type=\"text\"]"));
        searchBar.sendKeys(arananKelime);
      //  Thread.sleep(1000);
        WebElement searchButton=driver.findElement(By.cssSelector(".input-group-btn"));
        searchButton.click();
        List<WebElement> urunListesi=driver.findElements(By.cssSelector(".product-thumb>div>div>h4>a")); //.product-thumb>div>div>p:not(.price)"));
        for (WebElement e:urunListesi) {
            System.out.println(e.getText());
            System.out.println();
            Assert.assertTrue(e.getText().toLowerCase().contains(arananKelime));

        }
    }
}

