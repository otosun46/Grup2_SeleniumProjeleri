/**
 * @Author:Otosun Tarih :02/09/2020
 */
package Gun08;

import utils.BaseStaticDriver;

public class RelativeXpathVsAbsoluteXpath extends BaseStaticDriver {
    /*
           interviewlarda kaç çeşit xpath vardır şeklinde soru gelebilir.

           Relative Xpath denir.
           //input[@id='user-name']
           1- // başlıyor.
           2- Elemanı direk bulur, baştan itibaren diğer elemanlara bağlı kalmaz.


          Absolute Xpath deniyor.
          /html/body/div[2]/div/div/div/form/input
          1- / başlıyor.
          2- En baştan HTML den başlyarak bir yol bulur.Araya başka eleman girdiğind eyol kaybolur.
             Bu yüzden kullanışsızdır.
     */
}
