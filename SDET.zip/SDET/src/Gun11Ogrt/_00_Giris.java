package Gun11Ogrt;

public class _00_Giris {
    public static void main(String[] args) {
        /*
            Interview Soruları :
               Actions class ıyla neler yapabilirsiniz ?
                  Hoverover, double click, right click, drag and drop, Özel tuşlara basma işlemi (Shift, Control)
                  click

               Hover Over selenium da nasıl yaparsınız ?
                  moveToElement metoduyla yapıyoruz.

              Yazılışı nasıl, kullanımı nasıl yazılır ? (Syntax ı nasıldır ?)
                  Actions aksiyonlar=new Actions(driver); // tarayıcıyı WebDriver da aksiyonları kullanabilmek için yazıyoruz.

                  Pazartesi : Actions
                  Salı      : ImplicitWaiting, ExplicitWaiting    , beklemeler, senkronizayson
                  Çarşamba  : Alert ve iframe
                  Perşembe  : Scrolling

                  Pazartesi : Robot Class
                  Salı      : Kalan parça konular
                  Çarşamba  : Selenium Konu Tekrarı  (Ana konu olarak bitiyor)
                  Perşembe  : TestNG (testi güzel çalış ve Raporlama) (10 gün)
                  Sonra Cucumber konusu (10 gün)
         */
    }
}
